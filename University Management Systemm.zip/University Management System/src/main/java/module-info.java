module universitymanagment.com.universitymanagementsystem {
    requires javafx.controls;
    requires javafx.fxml;


    opens universitymanagment.com.universitymanagementsystem to javafx.fxml;
    exports universitymanagment.com.universitymanagementsystem;
}